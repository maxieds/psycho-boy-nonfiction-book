//import DNJEdefs;
//import DNJEutils;


texpreamble("\usepackage[T1]{fontenc}");
texpreamble("\usepackage{textcomp}   ");
texpreamble("\usepackage{chmath}     ");
texpreamble("\usepackage{chams}      ");    
texpreamble("\usepackage{bm}         ");
texpreamble("\usepackage{relsize}    ");

texpreamble("\usepackage{mattens}    ");

texpreamble("\newcommand*\usub[1]{_{\mathrm{#1}}}  ");

//-- My pens ------------------------------------

defaultpen(fontsize(10));

real thinLineWidth   = 0.50bp;
real mthinLineWidth  = 1.00bp;
real medLineWidth    = 1.50bp;

pen thinpen = linewidth(thinLineWidth  );
pen vecpen  = linewidth(mthinLineWidth );
pen uvecpen = linewidth(medLineWidth   );

real Asize = 3.0;

//-- Point -------------------------------------------

pair LinePt(pair A, pair B, real alf) 
{
    return A + alf*(B-A);
}
